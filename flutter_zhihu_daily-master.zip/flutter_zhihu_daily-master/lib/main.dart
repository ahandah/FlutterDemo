import 'package:flutter/material.dart';
import 'pages/DailyPage.dart';

void main() => runApp(new DailyPage());
