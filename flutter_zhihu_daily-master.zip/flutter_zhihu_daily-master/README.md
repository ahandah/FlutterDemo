# flutter_zhihu_daily

A new Flutter application.

## Getting Started

知乎日报 flutter 客户端，功能完善中...
# 截图

<div>
  <img src='http://ww1.sinaimg.cn/large/81eeb0fcgy1ftgayuatlej20u01o019y.jpg' width=200>
    <img src='http://ww1.sinaimg.cn/large/81eeb0fcgy1ftgayqiihsj20u01o07d3.jpg' width=200>
  
    <img src='http://ww1.sinaimg.cn/large/81eeb0fcgy1ftgayuf6kij20u01o0dy4.jpg' width=200>
</div>

# flutter 学习资料
[flutter 中文网](https://flutterchina.club/tutorials/layout/#approach)